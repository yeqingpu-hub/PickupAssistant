package com.pickupassistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PickupAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var attempts = 0

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.xunmeng.pinduoduo") return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        if (attempts == 0) {
            attempts = 1
            handler.postDelayed({ tryClickScan() }, 900)
        }
    }

    private fun tryClickScan() {
        val root = rootInActiveWindow ?: run { retry(); return }
        for (keyword in listOf("扫一扫", "扫码", "扫描")) {
            for (node in root.findAccessibilityNodeInfosByText(keyword)) {
                if (clickNode(node)) { attempts = 0; return }
            }
        }
        for (node in findByDescription(root, "扫一扫") + findByDescription(root, "扫码") + findByDescription(root, "相机")) {
            if (clickNode(node)) {
                attempts = 1
                handler.postDelayed({ tryClickScan() }, 1000)
                return
            }
        }
        retry()
    }

    private fun retry() {
        if (attempts >= 6) { attempts = 0; return }
        attempts++
        handler.postDelayed({ tryClickScan() }, 800)
    }

    private fun findByDescription(root: AccessibilityNodeInfo, text: String): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        fun walk(node: AccessibilityNodeInfo) {
            if (node.contentDescription?.toString()?.contains(text) == true) result.add(node)
            for (i in 0 until node.childCount) node.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return result
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable && current.isEnabled) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
