package com.pickupassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

/**
 * 扫描驿站二维码：读取二维码内容后，根据链接/域名自动识别购物平台，
 * 再把原始链接交给对应 App 处理。这样不需要提前知道取件码。
 */
class ScanActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startScanner()
    }

    private fun startScanner() {
        val integrator = IntentIntegrator(this).apply {
            setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            setPrompt("请扫描驿站取件二维码")
            setBeepEnabled(true)
            setOrientationLocked(false)
            setCameraId(0)
        }
        integrator.initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result: IntentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            ?: return super.onActivityResult(requestCode, resultCode, data)

        val raw = result.contents
        if (raw.isNullOrBlank()) {
            finish()
            return
        }

        val platform = detectPlatform(raw)
        if (platform == null) {
            Toast.makeText(this, "无法识别该驿站二维码对应的平台", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        openPlatformLink(this, platform, raw)
        finish()
    }

    private fun openPlatformLink(context: Context, platform: String, raw: String) {
        val packageName = when (platform) {
            "拼多多" -> "com.xunmeng.pinduoduo"
            "淘宝" -> "com.taobao.taobao"
            "京东" -> "com.jingdong.app.mall"
            "抖音商城" -> "com.ss.android.ugc.aweme"
            "得物" -> "com.shizhuang.duapp"
            else -> null
        }

        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || uri.scheme.isNullOrBlank()) {
            Toast.makeText(context, "二维码内容不是有效链接", Toast.LENGTH_LONG).show()
            return
        }

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            if (packageName != null) setPackage(packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                Toast.makeText(context, "已识别为$platform，但未安装对应 App", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            Toast.makeText(context, "无法打开$platform，请确认 App 已安装", Toast.LENGTH_LONG).show()
        }
    }

    private fun detectPlatform(raw: String): String? {
        val lower = raw.trim().lowercase()
        val host = runCatching { Uri.parse(lower).host.orEmpty() }.getOrDefault("")

        return when {
            host == "mdkd.pinduoduo.com" || host.endsWith(".pinduoduo.com") ||
                host == "pinduoduo.com" || host.endsWith(".yangkeduo.com") -> "拼多多"

            host == "taobao.com" || host.endsWith(".taobao.com") ||
                host == "tb.cn" || host.endsWith(".tb.cn") -> "淘宝"

            host == "jd.com" || host.endsWith(".jd.com") ||
                host == "3.cn" || host.endsWith(".3.cn") -> "京东"

            host == "douyin.com" || host.endsWith(".douyin.com") ||
                host == "iesdouyin.com" || host.endsWith(".iesdouyin.com") -> "抖音商城"

            host == "dewu.com" || host.endsWith(".dewu.com") ||
                host == "shizhuang.com" || host.endsWith(".shizhuang.com") -> "得物"

            lower.startsWith("pinduoduo://") -> "拼多多"
            lower.startsWith("taobao://") -> "淘宝"
            lower.startsWith("openapp.jdmobile://") || lower.startsWith("jd://") -> "京东"
            lower.startsWith("snssdk") -> "抖音商城"
            lower.startsWith("dewu://") -> "得物"
            else -> null
        }
    }
}
