package com.pickupassistant

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pickup_codes")
data class PickupCode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val platform: String,
    val sourcePackage: String,
    val message: String,
    val createdAt: Long = System.currentTimeMillis()
)
