package com.pickupassistant

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PickupDao {
    @Query("SELECT * FROM pickup_codes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<PickupCode>>

    @Insert
    suspend fun insert(item: PickupCode)

    @Query("DELETE FROM pickup_codes")
    suspend fun clear()
}
