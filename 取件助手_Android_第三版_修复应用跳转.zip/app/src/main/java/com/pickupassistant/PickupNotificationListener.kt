package com.pickupassistant

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.regex.Pattern

class PickupNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    private val patterns = listOf(
        Pattern.compile("""(?<!\d)\d{3}[-－]\d{3}(?!\d)"""),
        Pattern.compile("""(?<!\d)\d{6}(?!\d)""")
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val title = extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val content = "$title $text $big".trim()

        if (!isPickupMessage(content)) return

        val code = findCode(content) ?: return
        val platform = Platforms.fromPackage(sbn.packageName)
            ?: Platforms.fromText(content)
            ?: Platform("其他", "", "📦")

        scope.launch {
            AppDatabase.get(applicationContext).pickupDao().insert(
                PickupCode(
                    code = code,
                    platform = platform.name,
                    sourcePackage = sbn.packageName,
                    message = content.take(300)
                )
            )
        }

        // 默认关闭自动打开，避免普通通知导致 App 突然跳转。
        // 用户在设置中开启后，才会尝试打开对应平台。
        if (SettingsStore(applicationContext).autoOpen && platform.packageName.isNotBlank()) {
            val launch = packageManager.getLaunchIntentForPackage(platform.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
        }
    }

    private fun isPickupMessage(text: String): Boolean {
        val keywords = listOf(
            "取件码", "取货码", "取件", "取货", "驿站",
            "快递柜", "包裹已到", "已到站", "待取件", "自提"
        )
        return keywords.any { text.contains(it, ignoreCase = true) }
    }

    private fun findCode(text: String): String? {
        for (p in patterns) {
            val m = p.matcher(text)
            if (m.find()) return m.group()
        }
        return null
    }
}
