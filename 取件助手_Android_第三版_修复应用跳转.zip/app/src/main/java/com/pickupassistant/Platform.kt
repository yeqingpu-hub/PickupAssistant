package com.pickupassistant

data class Platform(
    val name: String,
    val packageName: String,
    val emoji: String
)

object Platforms {
    val all = listOf(
        Platform("拼多多", "com.xunmeng.pinduoduo", "🟠"),
        Platform("淘宝", "com.taobao.taobao", "🟡"),
        Platform("抖音商城", "com.ss.android.ugc.aweme", "🔴"),
        Platform("京东", "com.jingdong.app.mall", "🔵"),
        Platform("得物", "com.shizhuang.duapp", "🟣")
    )

    fun fromPackage(pkg: String): Platform? {
        return all.firstOrNull { pkg == it.packageName }
    }

    fun fromText(text: String): Platform? {
        val rules = listOf(
            "拼多多" to all[0],
            "淘宝" to all[1],
            "天猫" to all[1],
            "抖音" to all[2],
            "抖音商城" to all[2],
            "京东" to all[3],
            "得物" to all[4],
            "毒" to all[4]
        )
        return rules.firstOrNull { text.contains(it.first, ignoreCase = true) }?.second
    }
}
