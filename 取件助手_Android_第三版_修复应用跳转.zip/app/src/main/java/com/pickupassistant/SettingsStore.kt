package com.pickupassistant

import android.content.Context

class SettingsStore(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var autoOpen: Boolean
        get() = sp.getBoolean("auto_open", false)
        set(value) { sp.edit().putBoolean("auto_open", value).apply() }
}
