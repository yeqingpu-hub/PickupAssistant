package com.pickupassistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private lateinit var settings: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase.get(this)
        settings = SettingsStore(this)

        setContent {
            MaterialTheme {
                PickupApp(
                    db = db,
                    settings = settings,
                    notificationEnabled = NotificationManagerCompat
                        .getEnabledListenerPackages(this)
                        .contains(packageName)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PickupApp(
    db: AppDatabase,
    settings: SettingsStore,
    notificationEnabled: Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val codes by db.pickupDao().observeAll().collectAsState(initial = emptyList())
    var autoOpen by remember { mutableStateOf(settings.autoOpen) }
    var showSettings by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("取件助手", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { showSettings = !showSettings }) {
                        Text("设置")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (showSettings) {
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("自动处理", style = MaterialTheme.typography.titleMedium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("识别取件码后自动打开对应 App", Modifier.weight(1f))
                                Switch(
                                    checked = autoOpen,
                                    onCheckedChange = {
                                        autoOpen = it
                                        settings.autoOpen = it
                                    }
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "建议默认关闭。开启后，识别到取件通知可能会直接打开对应购物 App。",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            item {
                Text("购物平台", style = MaterialTheme.typography.titleLarge)
                Text("点击即可快速进入对应 App。", style = MaterialTheme.typography.bodyMedium)
            }

            items(Platforms.all) { p ->
                Card(
                    onClick = { openPlatform(context, p) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(p.emoji, style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.width(12.dp))
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.weight(1f))
                        Text("打开 ›")
                    }
                }
            }

            item {
                HorizontalDivider()
                Text("最近取件码", style = MaterialTheme.typography.titleLarge)
            }

            if (codes.isEmpty()) {
                item {
                    Card {
                        Text(
                            "还没有识别到取件码。\n请先开启“通知使用权”，收到快递通知后软件会自动识别。",
                            Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(codes.take(30), key = { it.id }) { item ->
                    PickupCard(item)
                }
            }

            item {
                if (!notificationEnabled) {
                    Button(
                        onClick = {
                            context.startActivity(
                                Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("开启通知读取")
                    }
                } else {
                    OutlinedButton(
                        onClick = { scope.launch { db.pickupDao().clear() } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("清空历史记录")
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun PickupCard(item: PickupCode) {
    val context = LocalContext.current
    val time = remember(item.createdAt) {
        SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(item.createdAt))
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.platform, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text(time, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                item.code,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(item.message, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("取件码", item.code))
            }) {
                Text("复制取件码")
            }
        }
    }
}

private fun openPlatform(context: Context, p: Platform) {
    val intent = context.packageManager.getLaunchIntentForPackage(p.packageName)
    if (intent != null) {
        context.startActivity(intent)
    } else {
        val market = Intent(Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse("market://details?id=${p.packageName}")
        }
        runCatching { context.startActivity(market) }
    }
}
